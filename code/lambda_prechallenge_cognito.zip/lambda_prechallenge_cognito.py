def lambda_handler(event, context):
    # apenas retornando sucesso
    event['response']['issueTokens'] = True
    event['response']['failAuthentication'] = False
    return event
